def print_hello():
    print('hello')

class MyClass:

    def __init__(self, word) -> None:
        self.word = word

    def print(self):
        print(self.word)